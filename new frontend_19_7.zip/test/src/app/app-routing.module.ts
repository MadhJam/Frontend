import { Routes, RouterModule } from "@angular/router";
import { MoviesListComponent } from "./movies-list/movies-list.component";
import { MovieListResolverService } from "./service/movie-list-resolver.service";
import { MovieDetailsComponent } from "./movies-list/movie-details/movie-details.component";
import { MovieDetailsGuardService } from "./service/movie-details-guard.service";
import { AddMovieComponent } from "./movies-list/add-movie/add-movie.component";
import { AddMovieCanDeactivateGuardService } from "./service/add-movie-can-deactivate-guard.service";
import { UserLoginComponent } from "./User Management/user-login/user-login.component";
import { PageNotFoundComponent } from "./page-not-found/page-not-found.component";
import { UserLogoutComponent } from "./User Management/user-logout/user-logout.component";
import { NgModule } from "@angular/core";
import { MultiplexListComponent } from "./multiplex-list/multiplex-list.component";
import { MultiplexDetailsComponent } from "./multiplex-list/multiplex-details/multiplex-details.component";
import { AddMultiplexComponent } from "./multiplex-list/add-multiplex/add-multiplex.component";
import { AddMultiplexCanDeactivateService } from "./service/multiplex/add-multiplex-can-deactivate.service";
import { MultiplexDetailsGuardService } from "./service/multiplex/multiplex-details-guard.service";
import { MultiplexListResolverService } from "./service/multiplex/multiplex-list-resolver.service";


const appRoutes:Routes=[ 
    {path:"movieList",component: MoviesListComponent,resolve:{movieList:MovieListResolverService}/*,canActivate:[AuthGuardService]*/},
    {path:"movies/:id",component: MovieDetailsComponent,canActivate:[MovieDetailsGuardService]},
    {path:"multiplexList",component: MultiplexListComponent,resolve:{multiplexList:MultiplexListResolverService}/*,canActivate:[AuthGuardService]*/},
    {path:"multiplex/:multiplexId",component: MultiplexDetailsComponent,canActivate:[MultiplexDetailsGuardService]},
    {path:"addMultiplex",component: AddMultiplexComponent,canDeactivate:[AddMultiplexCanDeactivateService]},
    {path:"editMultiplex/:multiplexId",component: AddMultiplexComponent,canDeactivate:[AddMultiplexCanDeactivateService]},
    {path:"addMovie",component:AddMovieComponent,canDeactivate:[AddMovieCanDeactivateGuardService]/*,canActivate:[AuthGuardService]*/},
    {path:"edit/:id",component:AddMovieComponent,canDeactivate:[AddMovieCanDeactivateGuardService]/*,canActivate:[AuthGuardService]*/},
    {path:"login",component:UserLoginComponent},
    {path:"",redirectTo:"/movieList",pathMatch:"full"},
    {path:"notfound",component:PageNotFoundComponent},
    {path:"logout",component:UserLogoutComponent},
  ];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 
  
}
