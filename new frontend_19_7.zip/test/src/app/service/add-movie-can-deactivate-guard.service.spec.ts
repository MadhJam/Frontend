import { TestBed } from '@angular/core/testing';

import { AddMovieCanDeactivateGuardService } from './add-movie-can-deactivate-guard.service';

describe('AddMovieCanDeactivateGuardService', () => {
  let service: AddMovieCanDeactivateGuardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AddMovieCanDeactivateGuardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
