import { TestBed } from '@angular/core/testing';

import { MovieListResolverService } from './movie-list-resolver.service';

describe('MovieListResolverService', () => {
  let service: MovieListResolverService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MovieListResolverService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
