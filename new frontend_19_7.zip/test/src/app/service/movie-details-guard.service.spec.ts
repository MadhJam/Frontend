import { TestBed } from '@angular/core/testing';

import { MovieDetailsGuardService } from './movie-details-guard.service';

describe('MovieDetailsGuardService', () => {
  let service: MovieDetailsGuardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MovieDetailsGuardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
