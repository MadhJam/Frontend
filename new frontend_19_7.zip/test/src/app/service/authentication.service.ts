import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import {map} from 'rxjs/operators';
const VALIDATION_URL= "http://localhost:8765/micro-user/api/user/login";

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {


  constructor(private httpClient : HttpClient){

  }

  authenticate(loginid : string, password : string){
 
    let authToken = "Basic " + window.btoa(loginid + ":" + password);
    console.log(authToken);
    
  
    let headers = new HttpHeaders({
      Authorization : authToken 
    });

    return this.httpClient.get(VALIDATION_URL, {headers,responseType : "text" }).pipe(
     
      map((successData:string) => {
        console.log("AUTH SUCCESS :" +  successData);
        sessionStorage.setItem("user", loginid);
        sessionStorage.setItem("token", authToken);
        return successData;
      }),
  
      map((failureData:string) => {
        console.log("AUTH FAILED :" +  failureData);
        return failureData;
      })
    );

  }

  // method to return token
  getAuthenticationToken(){
    return sessionStorage.getItem("token");
  }


  isUserLoggedIn(): boolean{
    // if 'user' key is present
    let user = sessionStorage.getItem('user');
    if(user == null)
      return false;
    else
      return true;  
  }

  //  can have method to return type of user

  logout(){
    sessionStorage.removeItem('user');
    sessionStorage.removeItem('token');
  }

}

