import { TestBed } from '@angular/core/testing';

import { MultiplexListResolverService } from './multiplex-list-resolver.service';

describe('MultiplexListResolverService', () => {
  let service: MultiplexListResolverService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MultiplexListResolverService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
