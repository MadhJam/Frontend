import { Injectable } from '@angular/core';
import { Observable,throwError } from 'rxjs';
import {catchError} from 'rxjs/operators';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import { Multiplex } from '../../models/multiplex.model';

@Injectable({
  providedIn: 'root'
})
export class MultiplexService {
  private baseUrl = 'http://localhost:3000/multiplexes';
  
  constructor(private httpClient:HttpClient) { }
  
  getMultiplexes():Observable<Multiplex[]>{
    return this.httpClient.get<Multiplex[]>(`${this.baseUrl}`)
             .pipe(catchError(this.handleError));
  }

  private handleError(errorResponse:HttpErrorResponse){
    if(errorResponse.error instanceof ErrorEvent){
      console.error('Client Side Error',errorResponse.error.message);
    }
    else{
     console.error('Server Side Error',errorResponse);
    }
    return throwError('There is a problem with the service.We are notified and working on it.Please try again later');
  }
  getMultiplex(multiplexId:string):Observable<Multiplex>{
   return this.httpClient.get<Multiplex>(`${this.baseUrl}/${multiplexId}`)
             .pipe(catchError(this.handleError));
   //listMovies.find(m=>m.id===id);
 }

 addMultiplex(multiplex:Multiplex):Observable<Multiplex>{
  return this.httpClient.post<Multiplex>(`${this.baseUrl}`, multiplex)
            .pipe(catchError(this.handleError));
 }
 
 updateMultiplex(multiplexId: string, value: any): Observable<Multiplex> {
  return this.httpClient.put<Multiplex>(`${this.baseUrl}/${multiplexId}`, value);
}

 deleteMultiplex(multiplexId:string){
    return this.httpClient.delete<void>(`${this.baseUrl}/${multiplexId}` )
      .pipe(catchError(this.handleError));
 }

}
