import { Injectable } from '@angular/core';
import { AddMultiplexComponent } from '../../multiplex-list/add-multiplex/add-multiplex.component';
import { CanDeactivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AddMultiplexCanDeactivateService implements CanDeactivate<AddMultiplexComponent>{

  canDeactivate(component:AddMultiplexComponent): boolean {
    if(component.addMultiplexForm.dirty){
      return confirm('Are you sure you want to discard your changes?');
    }
    return true;
  }
}
