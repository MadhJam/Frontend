import { TestBed } from '@angular/core/testing';

import { MultiplexDetailsGuardService } from './multiplex-details-guard.service';

describe('MultiplexDetailsGuardService', () => {
  let service: MultiplexDetailsGuardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MultiplexDetailsGuardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
