import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Multiplex } from '../../models/multiplex.model';
import { MultiplexService } from './multiplex.service';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class MultiplexListResolverService implements Resolve<Multiplex[]|string> {
  constructor(private multiplexService:MultiplexService) { }
  resolve(route:ActivatedRouteSnapshot,state:RouterStateSnapshot):Observable<Multiplex[]|string>{
      return this.multiplexService.getMultiplexes()
        .pipe(
          catchError((error:string)=>of(error))
        );
  }
}
