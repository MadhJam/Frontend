import { TestBed } from '@angular/core/testing';

import { AddMultiplexCanDeactivateService } from './add-multiplex-can-deactivate.service';

describe('AddMultiplexCanDeactivateService', () => {
  let service: AddMultiplexCanDeactivateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AddMultiplexCanDeactivateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
