import { Injectable } from '@angular/core';
import { Movie } from '../models/movie.model';
import { Observable,throwError } from 'rxjs';
import {catchError} from 'rxjs/operators';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MovieService {
  private baseUrl = 'http://localhost:3000/movies';
  constructor(private httpClient:HttpClient) { }
   /*private listMovies:Movie[]=[{id:"1",movieName:"Golmaal",category:"comedy",producer:"Irani",director:"Ramgopal",releaseDate:new Date('11/20/1979'),photoPath:"assets/images/movie1.png"},
   {id:"2",movieName:"NH10",category:"thriller",producer:"Anuska",director:"S.M",releaseDate:new Date('10/09/2010'),photoPath:"assets/images/movie2.png"},
   {id:"3",movieName:"Fast5",category:"action",producer:"Vin",director:"Bolleni",releaseDate:new Date('11/06/2015'),photoPath:"assets/images/movie3.png"}];*/

   getMovies():Observable<Movie[]>{
     return this.httpClient.get<Movie[]>(`${this.baseUrl}`)
              .pipe(catchError(this.handleError));
   }

   private handleError(errorResponse:HttpErrorResponse){
     if(errorResponse.error instanceof ErrorEvent){
       console.error('Client Side Error',errorResponse.error.message);
     }
     else{
      console.error('Server Side Error',errorResponse);
     }
     return throwError('There is a problem with the service.We are notified and working on it.Please try again later');
   }
   getMovie(id:string):Observable<Movie>{
    return this.httpClient.get<Movie>(`${this.baseUrl}/${id}`)
              .pipe(catchError(this.handleError));
    //listMovies.find(m=>m.id===id);
  }

   addMovie(movie:Movie):Observable<Movie>{
    return this.httpClient.post<Movie>(`${this.baseUrl}`, movie)
              .pipe(catchError(this.handleError));
   }
   
   updateMovie(id: string, value: any): Observable<Movie> {
    return this.httpClient.put<Movie>(`${this.baseUrl}/${id}`, value);
  }
  
   deleteMovie(id:string){
      return this.httpClient.delete<void>(`${this.baseUrl}/${id}` )
        .pipe(catchError(this.handleError));
   }
  
}
