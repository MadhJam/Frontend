import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { AddMovieComponent } from '../movies-list/add-movie/add-movie.component';

@Injectable({
  providedIn: 'root'
})
export class AddMovieCanDeactivateGuardService implements CanDeactivate<AddMovieComponent>{

  canDeactivate(component:AddMovieComponent ): boolean {
    if(component.addMovieForm.dirty){
      return confirm('Are you sure you want to discard your changes?');
    }
    return true;
  }

  constructor() { }
}
