import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class HttpInterceptorService implements  HttpInterceptor{

  constructor(private auth : AuthenticationService) { }

  intercept(request: HttpRequest<any>, next: HttpHandler) {
    if(this.auth.isUserLoggedIn()){
      let token = this.auth.getAuthenticationToken();

      request = request.clone({
        setHeaders : {
          Authorization : token
        }
      });

      return next.handle(request);
    }
  }
}

