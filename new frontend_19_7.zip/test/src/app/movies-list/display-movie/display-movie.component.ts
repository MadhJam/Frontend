import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Movie } from '../../models/movie.model';
import { Router} from '@angular/router';
import { MovieService } from '../../service/movie.service';

@Component({
  selector: 'app-display-movie',
  templateUrl: './display-movie.component.html',
  styleUrls: ['./display-movie.component.css']
})
export class DisplayMovieComponent implements OnInit {
 @Input() movie :Movie;
 @Input() searchTerm:string;
 @Output() notifyDelete:EventEmitter<string>=new EventEmitter<string>();
 confirmDelete=false;

  constructor(private router:Router,private movieService:MovieService) { }

  ngOnInit(): void {
  }

  viewMovie(){
    this.router.navigate(['/movies',this.movie.id],{
      queryParams:{'searchTerm':this.searchTerm}
    });
  }
  editMovie(movieId:string){
    this.router.navigate(['/edit',movieId]);
  }
  deleteMovie(){
    this.movieService.deleteMovie(this.movie.id).subscribe(()=>console.log(`Movie with ID=${this.movie.id} deleted`),
    (err)=>console.log(err)
    );
    this.notifyDelete.emit(this.movie.id);
  }
}
