import { Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Category } from '../../models/category.model';
import {BsDatepickerConfig} from 'ngx-bootstrap/datepicker';
import { MovieService } from '../../service/movie.service';
import { Movie } from '../../models/movie.model';



@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {
  movieId:string;
  editMode=false;
  movie:Movie;
  previewPhoto=false;
  datePickerConfig:Partial<BsDatepickerConfig>;
  movieName:string;
  producer:string;
  director:string;
  category: Category[] = [{id:1,category:'Action'},
                          {id:2,category:'Horror'},
                          {id:3,category:'Romance'},
                          {id:4,category:'Comedy'}];
  releaseDate:Date;
  photoPath:string;

  addMovieForm: FormGroup;
  constructor(formBuilder : FormBuilder,private router:Router,private _movieService:MovieService,private route:ActivatedRoute) { 
  // this.movie=new Movie('a','b','c','d','e',new Date('10/09/2010'),'');
    this.addMovieForm = formBuilder.group({
      "movieName" : new FormControl('',Validators.required),
      "category" : new FormControl('',Validators.required),
      "producer" : new FormControl('',[Validators.required,Validators.minLength(3)]),
      "director" : new FormControl('',[Validators.required,Validators.minLength(3)]),
      "releaseDate":new FormControl('',Validators.required),
      "photoPath":new FormControl('',Validators.required)
    });
    this.datePickerConfig=Object.assign({},
      {
      containerClass:'theme-dark-blue',
      showWeekNumbers:false,
      dateInputFormat:'DD/MM/YYYY'
    });
  }
 


  ngOnInit(): void {
   this.route.paramMap.subscribe(parameterMap=>{
       this.movieId=parameterMap.get('id');
      console.log(this.movieId);
      if(this.movieId){
      this.getMovieItems(this.movieId);}
    });
  }
  getMovieItems(movieId:string){
    this._movieService.getMovie(movieId).subscribe(
      (movie:Movie)=>this.editMovie(movie),
      (err:any)=>console.log(err)
    );
  }
  editMovie(movie:Movie){
        this.editMode=true;
        this.addMovieForm.patchValue({
        movieName:movie.movieName,
        cat:movie.category,
        producer:movie.producer,
        director:movie.director,
        releaseDate:movie.releaseDate,
        photoPath:movie.photoPath
      })
  }
  get f(){
    return this.addMovieForm.controls;
  }
  togglePhotoPreview(){
    this.previewPhoto=!this.previewPhoto;
  }
  save(){
    this.movieName = this.addMovieForm.controls['movieName'].value;
    this.category = this.addMovieForm.controls['category'].value;
    this.producer = this.addMovieForm.controls['producer'].value;
    this.director = this.addMovieForm.controls['director'].value;
    this.releaseDate=this.addMovieForm.controls['releaseDate'].value;
    this.photoPath=this.addMovieForm.controls['photoPath'].value;
    if(this.editMode){
      let movie = new Movie(this.movieId,this.movieName,this.category.toString(),this.producer,this.director,this.releaseDate,this.photoPath);
      this._movieService.updateMovie(this.movieId,movie).subscribe(data=>
        {
        console.log(data);   
        this.addMovieForm.reset();
        this.router.navigate(['/movieList']);
        },
        error=>console.log(error));
    }
    else{
    let movie = new Movie(null,this.movieName,this.category.toString(),this.producer,this.director,this.releaseDate,this.photoPath);
    this._movieService.addMovie(movie).subscribe(data=>
    {
    console.log(data);   
    this.addMovieForm.reset();
    this.router.navigate(['/movieList']);
    },
    error=>console.log(error));
         }
  }
}
