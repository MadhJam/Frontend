export class Multiplex{
    constructor(public multiplexId:string,public multiplexName:string,
         public address:string, public numberOfScreens:number,public photoPath:string){
    }
}

