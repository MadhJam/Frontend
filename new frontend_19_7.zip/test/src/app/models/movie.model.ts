import { Category } from "./category.model";

export class Movie{
    constructor(public id:string,public movieName:string, public category:string, public producer:string,
        public director:string,public releaseDate:Date,public photoPath:string){
        
    }
}

