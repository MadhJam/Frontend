import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../service/authentication.service';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  loginName:string;
  password:string;
  errorMessage : string;
  authorized : boolean;

  userFormGroup : FormGroup;
  constructor(formBuilder : FormBuilder,private router: Router,public auth: AuthenticationService) { 
    this.userFormGroup = formBuilder.group({
      "user_name" : new FormControl('',Validators.required),
      "password" : new FormControl('',Validators.required)
    });
    this.errorMessage = "Invalid Credentials!!!";
    this.authorized = true;
  }
  get f(){
    return this.userFormGroup.controls;
  }
  authenticate(){
    this.loginName = this.userFormGroup.controls['user_name'].value;
    this.password = this.userFormGroup.controls['password'].value;
    this.auth.authenticate(this.loginName, this.password)
    .subscribe(
      // success Method
      (successData:string) => {
        console.log("LOGIN SUCCESS :" + successData);
        this.authorized = true; 
        this.router.navigate(['/movieList']);
      },
      // failure
      failureData => {
        console.log("LOGIN FAILURE :" + failureData);
        this.authorized = false;
      }
    );

  }

  ngOnInit(): void {
  }
}