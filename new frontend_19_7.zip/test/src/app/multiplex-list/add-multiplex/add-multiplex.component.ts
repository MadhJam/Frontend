import { Component, OnInit } from '@angular/core';
import { Multiplex } from '../../models/multiplex.model';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MultiplexService } from '../../service/multiplex/multiplex.service';

@Component({
  selector: 'app-add-multiplex',
  templateUrl: './add-multiplex.component.html',
  styleUrls: ['./add-multiplex.component.css']
})
export class AddMultiplexComponent implements OnInit {
  multiplexId:string;
  editMode=false;
  multiplex:Multiplex;
  previewPhoto=false;
  multiplexName:string;
  address:string;
  numberOfScreens:number;
  photoPath:string;

  addMultiplexForm: FormGroup;
  constructor(formBuilder : FormBuilder,private router:Router,private _multiplexService:MultiplexService,private route:ActivatedRoute) { 
    this.addMultiplexForm = formBuilder.group({
      "multiplexName" : new FormControl('',Validators.required),
      "address" : new FormControl('',[Validators.required,Validators.minLength(8)]),
      "numberOfScreens" : new FormControl('',Validators.required),
      "photoPath":new FormControl('',Validators.required)
    });
  }
 


  ngOnInit(): void {
   this.route.paramMap.subscribe(parameterMap=>{
       this.multiplexId=parameterMap.get('multiplexId');
      console.log(this.multiplexId);
      if(this.multiplexId){
      this.getMultiplexItems(this.multiplexId);}
    });
  }
  getMultiplexItems(multiplexId:string){
    this._multiplexService.getMultiplex(multiplexId).subscribe(
      (multiplex:Multiplex)=>this.editMultiplex(multiplex),
      (err:any)=>console.log(err)
    );
  }
  editMultiplex(multiplex:Multiplex){
        this.editMode=true;
        this.addMultiplexForm.patchValue({
        multiplexName:multiplex.multiplexName,
        address:multiplex.address,
        numberOfScreens:multiplex.numberOfScreens,
        photoPath:multiplex.photoPath
      })
  }
  get f(){
    return this.addMultiplexForm.controls;
  }
  togglePhotoPreview(){
    this.previewPhoto=!this.previewPhoto;
  }
  save(){
    this.multiplexName = this.addMultiplexForm.controls['multiplexName'].value;
    this.address = this.addMultiplexForm.controls['address'].value;
    this.numberOfScreens = this.addMultiplexForm.controls['numberOfScreens'].value;
    this.photoPath=this.addMultiplexForm.controls['photoPath'].value;
    if(this.editMode){
      let multiplex = new Multiplex(this.multiplexId,this.multiplexName,this.address,this.numberOfScreens,this.photoPath);
      this._multiplexService.updateMultiplex(this.multiplexId,multiplex).subscribe(data=>
        {
        console.log(data);   
        this.addMultiplexForm.reset();
        this.router.navigate(['/multiplexList']);
        },
        error=>console.log(error));
    }
    else{
    let multiplex = new Multiplex(null,this.multiplexName,this.address,this.numberOfScreens,this.photoPath);
    this._multiplexService.addMultiplex(multiplex).subscribe(data=>
    {
    console.log(data);   
    this.addMultiplexForm.reset();
    this.router.navigate(['/multiplexList']);
    },
    error=>console.log(error));
         }
  }

}
