import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Multiplex } from '../../models/multiplex.model';
import { MultiplexService } from '../../service/multiplex/multiplex.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-display-multiplex',
  templateUrl: './display-multiplex.component.html',
  styleUrls: ['./display-multiplex.component.css']
})
export class DisplayMultiplexComponent implements OnInit {
  @Input() multiplex:Multiplex;
  @Input() searchTerm:string;
  @Output() notifyDelete:EventEmitter<string>=new EventEmitter<string>();
  confirmDelete=false;
 
   constructor(private router:Router,private multiplexService:MultiplexService) { }
 
   ngOnInit(): void {
   }
 
   viewMultiplex(){
     this.router.navigate(['/multiplex',this.multiplex.multiplexId],{
       queryParams:{'searchTerm':this.searchTerm}
     });
   }
   editMultiplex(multiplexId:string){
     this.router.navigate(['/editMultiplex',multiplexId]);
   }
   deleteMultiplex(){
     this.multiplexService.deleteMultiplex(this.multiplex.multiplexId).subscribe(()=>console.log(`Multiplex with ID=${this.multiplex.multiplexId} deleted`),
     (err)=>console.log(err)
     );
     this.notifyDelete.emit(this.multiplex.multiplexId);
   }

}
