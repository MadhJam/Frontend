import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayMultiplexComponent } from './display-multiplex.component';

describe('DisplayMultiplexComponent', () => {
  let component: DisplayMultiplexComponent;
  let fixture: ComponentFixture<DisplayMultiplexComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplayMultiplexComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayMultiplexComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
